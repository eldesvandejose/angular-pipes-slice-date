import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'a02-supplier-edit',
  templateUrl: './supplier-edit.component.html',
  styleUrls: ['./supplier-edit.component.css']
})
export class SupplierEditComponent implements OnInit {

  identifier: any;

  constructor(private customer: ActivatedRoute) {}

  ngOnInit() {
    this.identifier = this.customer.snapshot.params['id'];
  }
}
