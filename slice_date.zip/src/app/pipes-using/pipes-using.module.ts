import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PipesCheckingComponent } from './pipes-checking/pipes-checking.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [PipesCheckingComponent],
  exports: [PipesCheckingComponent]
})
export class PipesUsingModule { }
