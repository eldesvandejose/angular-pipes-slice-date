import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-pipes-checking',
  templateUrl: './pipes-checking.component.html',
  styleUrls: ['./pipes-checking.component.css']
})
export class PipesCheckingComponent implements OnInit {

  cadena = 'Esto es un literal.';

  fecha = Date.now();

  constructor() { }

  ngOnInit() {
  }

}
